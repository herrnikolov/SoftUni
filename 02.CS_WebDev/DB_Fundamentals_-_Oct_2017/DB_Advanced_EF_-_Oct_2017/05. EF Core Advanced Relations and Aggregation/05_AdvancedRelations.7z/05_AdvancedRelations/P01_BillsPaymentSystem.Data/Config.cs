﻿namespace P01_BillsPaymentSystem.Data
{
    internal class Config
    {
        internal static string ConnectionString =>
            "Server=(LocalDb)\\MSSQLLocalDB;Database=BillsPaymentSystem;Integrated Security=True;";
    }
}
