﻿public class Configuration
{
    public static string ConnectionString => $@"Server=(LocalDb)\MSSQLLocalDB;Database=ProductsShop;Integrated Security=True";
}

