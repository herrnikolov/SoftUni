﻿namespace Forum.Services.Contracts
{
    public interface IDatabaseInitializerService
    {
	    void InitializeDatabase();
    }
}
