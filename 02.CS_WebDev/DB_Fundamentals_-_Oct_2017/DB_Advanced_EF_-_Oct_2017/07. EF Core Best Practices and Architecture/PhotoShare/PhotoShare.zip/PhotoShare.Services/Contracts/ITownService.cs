﻿namespace PhotoShare.Services.Contracts
{
    public interface ITownService
    {
        string AddTown(string townName, string countryName);

    }
}
