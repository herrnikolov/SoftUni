﻿namespace PhotoShare.Data
{
    public class ServerConfig
    {
        public static string ConnectionString => "Server=(LocalDb)\\MSSQLLocalDB;Database=PhotoShare;Integrated Security=True;";
    }
}
