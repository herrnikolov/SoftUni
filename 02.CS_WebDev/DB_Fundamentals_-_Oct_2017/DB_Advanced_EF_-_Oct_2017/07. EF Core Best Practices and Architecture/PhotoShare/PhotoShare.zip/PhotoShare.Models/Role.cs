﻿namespace PhotoShare.Models
{
    public enum Role
    {
        Owner,
        Viewer
    }
}
