﻿public class ServerConfiguration
{
    public static string ConnectionString => $@"Server=(LocalDb)\MSSQLLocalDB;Database=ProductsShop;Integrated Security=True";
}
