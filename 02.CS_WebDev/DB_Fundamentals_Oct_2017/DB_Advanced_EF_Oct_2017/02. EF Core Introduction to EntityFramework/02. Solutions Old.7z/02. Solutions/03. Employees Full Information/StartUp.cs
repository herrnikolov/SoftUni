﻿using System;
using P02_DatabaseFirst.Data;

namespace _03._Employees_Full_Information
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
