﻿using System;

namespace _01.__Inport_SoftUni_DataBase
{
    class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
