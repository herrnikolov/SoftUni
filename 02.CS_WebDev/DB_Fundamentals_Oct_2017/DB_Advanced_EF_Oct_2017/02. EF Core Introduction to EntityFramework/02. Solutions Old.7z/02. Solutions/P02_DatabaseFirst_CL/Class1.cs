﻿using System;

using P02_DatabaseFirst_CL.Data.Models;

namespace P02_DatabaseFirst_CL
{
    public class Class1
    {
    }
}
