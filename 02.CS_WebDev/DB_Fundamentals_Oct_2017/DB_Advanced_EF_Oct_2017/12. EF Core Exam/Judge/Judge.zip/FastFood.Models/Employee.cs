using System.ComponentModel.DataAnnotations;

namespace FastFood.Models
{
	public class Employee
	{
	    public int Id { get; set; }

        [MinLength(3)]
	    public string Name { get; set; }

        [MinLength(15)]
        [MaxLength(80)]
	    public int Age { get; set; }

	    public int PositionId { get; set; }

	    public Position Position { get; set; }

	    public Order Orders { get; set; }

        
	}
}