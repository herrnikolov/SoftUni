﻿namespace FastFood.Data.EntityConfiguration
{
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;

    using FastFood.Models;
    class OrderItemConfig : IEntityTypeConfiguration<OrderItem>
    {
        public void Configure(EntityTypeBuilder<OrderItem> builder)
        {
            builder.HasKey(e => new { e.OrderId, e.ItemId });

            //builder.Property(e => e.Order)
            //    .IsRequired();

            //builder.Property(e => e.Item)
            //    .IsRequired();

            //builder.Property(e => e.Quantity)
            //    .IsRequired();
        }
    }
}
