﻿namespace AnimalCentre.Models.Contracts
{
    public interface IProcedure
    {
       //Implement me
    }
}
