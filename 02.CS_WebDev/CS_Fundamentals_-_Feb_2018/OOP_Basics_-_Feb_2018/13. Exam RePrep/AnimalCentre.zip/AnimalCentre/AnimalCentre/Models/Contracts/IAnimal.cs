﻿namespace AnimalCentre.Models.Contracts
{
    public interface IAnimal
    {
       //Implement me
    }
}
