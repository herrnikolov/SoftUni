﻿public interface ICat
{
    string Name { get; set; }
}