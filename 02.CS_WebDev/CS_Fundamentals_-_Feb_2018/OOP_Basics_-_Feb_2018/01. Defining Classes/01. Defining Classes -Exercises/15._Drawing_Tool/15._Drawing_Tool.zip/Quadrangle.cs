﻿public abstract class Quadrangle
{
    public abstract void DrawQuadrangle();
}