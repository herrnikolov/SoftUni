﻿public static class Constants
{
    public static readonly string InvalidFeeding = "{0} does not eat {1}!";
}
