﻿public interface IAddableCollection
{
    int Add(string item);
}
