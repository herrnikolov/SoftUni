﻿public interface IRemovableCollection
{
    string Remove();
}