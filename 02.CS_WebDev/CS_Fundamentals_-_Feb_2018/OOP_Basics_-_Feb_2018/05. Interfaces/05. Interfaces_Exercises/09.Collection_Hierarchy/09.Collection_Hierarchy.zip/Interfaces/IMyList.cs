﻿public interface IMyList : IRemovableCollection
{
    int Used { get; }
}
