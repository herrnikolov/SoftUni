﻿public interface IBornable
{
    string Birthdate { get; }
}
