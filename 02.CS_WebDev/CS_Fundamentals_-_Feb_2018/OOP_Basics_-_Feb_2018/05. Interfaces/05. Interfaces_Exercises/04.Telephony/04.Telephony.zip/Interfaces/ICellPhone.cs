﻿public interface ICellPhone
{
    string Call(string number);

    string Browse(string webSite);
}