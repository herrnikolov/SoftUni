﻿namespace InfernoInfinity.Models.Weapons
{
    using InfernoInfinity.Models.Contracts;
    using InfernoInfinity.Models.Enums;
    using System.Linq;

    public abstract class BaseWeapon : IWeapon
    {
        protected BaseWeapon(string name, int minDamage, int maxDamage, IGem[] sockets, Rarity rarity)
        {
            this.Name = name;
            this.MinDamage = minDamage * (int)rarity;
            this.MaxDamage = maxDamage * (int)rarity;
            this.Sockets = sockets;
        }

        public string Name { get; private set; }

        public int MinDamage { get; private set; }

        public int MaxDamage { get; private set; }

        public IGem[] Sockets { get; private set; }

        public void AddGem(IGem gem, int index)
        {
            if (this.IsIndexValid(index))
            {
                this.Sockets[index] = gem;
                this.AddBonusPointsByGem(gem);
            }
        }
        
        public void RemoveGem(int index)
        {
            if (this.IsIndexValid(index))
            {
                var removedGem = this.Sockets[index];

                if (removedGem != null)
                {
                    this.Sockets[index] = null;
                    this.RemoveBonusPoinsByGem(removedGem);
                }
            }
        }

        private void RemoveBonusPoinsByGem(IGem gem)
        {
            this.MinDamage -= ((gem.Strength * 2) + (gem.Agility * 1));
            this.MaxDamage -= ((gem.Strength * 3) + (gem.Agility * 4));
        }

        private void AddBonusPointsByGem(IGem gem)
        {
            this.MinDamage += (gem.Strength * 2) + (gem.Agility * 1);
            this.MaxDamage += (gem.Strength * 3) + (gem.Agility * 4);
        }

        private bool IsIndexValid(int index) => index >= 0 && index < this.Sockets.Length;

        public override string ToString()
        {
            var strengthPoints = this.Sockets.Where(g => g != null).Sum(g => g.Strength);
            var agilityPoints = this.Sockets.Where(g => g != null).Sum(g => g.Agility);
            var vitalityPoints = this.Sockets.Where(g => g != null).Sum(g => g.Vitality);

            return $"{this.Name}: {this.MinDamage}-{this.MaxDamage} Damage, " +
                $"+{strengthPoints} Strength, +{agilityPoints} Agility, +{vitalityPoints} Vitality";
        }
    }
}
