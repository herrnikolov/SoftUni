﻿namespace InfernoInfinity.Models.Contracts
{
    public interface IGem
    {
        int Strength { get; }
        int Agility { get; }
        int Vitality { get; }
    }
}
