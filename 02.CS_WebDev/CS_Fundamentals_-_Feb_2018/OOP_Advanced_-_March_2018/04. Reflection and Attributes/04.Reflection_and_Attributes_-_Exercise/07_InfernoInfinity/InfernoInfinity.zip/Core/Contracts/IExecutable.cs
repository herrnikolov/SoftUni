﻿namespace InfernoInfinity.Core.Contracts
{
    public interface IExecutable
    {
        string Execute();
    }
}