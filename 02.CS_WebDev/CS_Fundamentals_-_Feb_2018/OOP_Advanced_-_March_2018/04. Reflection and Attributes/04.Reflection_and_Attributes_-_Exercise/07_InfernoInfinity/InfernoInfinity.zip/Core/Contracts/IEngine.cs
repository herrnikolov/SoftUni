﻿namespace InfernoInfinity.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
