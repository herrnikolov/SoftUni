﻿namespace InfernoInfinity.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
