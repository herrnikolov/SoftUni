﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrafficLights.Models.Enums
{
    public enum Signal
    {
        Red,
        Green,
        Yellow
    }
}
