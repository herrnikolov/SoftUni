﻿public interface IWriter
{
    void WriteLine(object obj);
}
