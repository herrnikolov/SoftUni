﻿namespace BookLibrary.Web.Models
{
    public class SearchViewModel
    {
        public int Id { get; set; }

        public string Type { get; set; }

        public string SearchResult { get; set; }
    }
}
