﻿using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;

namespace SoftUniClone.Models
{
    public class User : IdentityUser
    {
        public User()
        {
            this.EnrolledCourses = new List<StudentsInCourses>();
        }

        public string FullName { get; set; }

        public ICollection<StudentsInCourses> EnrolledCourses { get; set; }

        // TODO: Extract (e.g. into role)
        public ICollection<CourseInstance> LecturerCourses { get; set; }
    }
}
