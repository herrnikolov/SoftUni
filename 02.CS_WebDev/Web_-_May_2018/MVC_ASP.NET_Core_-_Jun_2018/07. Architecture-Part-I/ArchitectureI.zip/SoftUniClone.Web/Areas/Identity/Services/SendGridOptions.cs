﻿namespace SoftUniClone.Web.Areas.Identity.Services
{
    public class SendGridOptions
    {
        public string SendGridApiKey { get; set; }
    }
}
