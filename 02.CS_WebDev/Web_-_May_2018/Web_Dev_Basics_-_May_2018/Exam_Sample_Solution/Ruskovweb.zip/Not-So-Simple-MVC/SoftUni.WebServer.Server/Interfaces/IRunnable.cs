﻿namespace SoftUni.WebServer.Server.Interfaces
{
    public interface IRunnable
    {
        void Run();
    }
}
