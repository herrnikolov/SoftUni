﻿namespace Chushka.Data
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=.\SQLEXPRESS; Database=ChushkaDbRuskovweb; Integrated Security=True";
    }
}
