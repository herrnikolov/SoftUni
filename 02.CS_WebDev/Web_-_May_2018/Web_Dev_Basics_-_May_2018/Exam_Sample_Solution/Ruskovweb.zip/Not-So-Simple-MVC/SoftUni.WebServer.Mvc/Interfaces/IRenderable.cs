﻿namespace SoftUni.WebServer.Mvc.Interfaces
{
    public interface IRenderable
    {
        string Render();
    }
}
