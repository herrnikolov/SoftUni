﻿namespace Chushka.App.Common
{
    public class Constants
    {
        public const string PathPrefix = "../../../";
    }
}
