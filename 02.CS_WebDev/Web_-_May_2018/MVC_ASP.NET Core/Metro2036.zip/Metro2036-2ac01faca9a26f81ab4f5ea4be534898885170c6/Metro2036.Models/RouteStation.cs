﻿namespace Metro2036.Models
{
    public class RouteStation
    {
        public string RouteName { get; set; }

        public int RouteId { get; set; }

        public string StationName { get; set; }

        public int StationId { get; set; }
    }
}
