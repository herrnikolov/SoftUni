﻿namespace Metro2036.Common.Mapping
{
    public interface IMapFrom<TModel>
    {
    }
}
