﻿namespace Metro2036.Services.Implementations
{
    using Metro2036.Data;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    public class BaseService
    {
        //private readonly Metro2036DbContext db;

        //public BaseService(Metro2036DbContext db)
        //{
        //    this.db = db;
        //}
    }
}
