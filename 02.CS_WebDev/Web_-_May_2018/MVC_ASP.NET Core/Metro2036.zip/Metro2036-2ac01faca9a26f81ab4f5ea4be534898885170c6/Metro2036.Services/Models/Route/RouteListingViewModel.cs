﻿namespace Metro2036.Services.Models.Route
{
    using System.Collections.Generic;
    using Metro2036.Models;

    public class RouteListingViewModel
    {
        public IEnumerable<Station> Routes { get; set; }
    }
}
