﻿namespace Metro2036.Services.Models.Train
{
    using Metro2036.Models;
    using System.Collections.Generic;

    public class TrainIndexViewModel
    {
        public IEnumerable<Train> Trains { get; set; }
    }
}
