﻿namespace Metro2036.Services.Models.Station
{
    using System.Collections.Generic;
    using Metro2036.Models;

    public class StationIndexViewModel
    {
        public IEnumerable<Station> Stations { get; set; }
    }
}
