﻿namespace KittenApp.Web.Models.BindingModels
{
    public class KittenAddingModel
    {
        public string Name { get; set; }

        public int Age { get; set; }

        public string Breed { get; set; }
    }
}
