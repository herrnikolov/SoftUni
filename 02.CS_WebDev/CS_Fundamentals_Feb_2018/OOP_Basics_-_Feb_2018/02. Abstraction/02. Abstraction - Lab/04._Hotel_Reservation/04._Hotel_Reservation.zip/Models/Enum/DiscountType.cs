﻿using System;
using System.Collections.Generic;
using System.Text;

    public enum DiscountType
    {
        None = 0,
        SecondVisit = 1,
        VIP = 2
    }