﻿public interface IResident
{
    string Id { get; }
}
