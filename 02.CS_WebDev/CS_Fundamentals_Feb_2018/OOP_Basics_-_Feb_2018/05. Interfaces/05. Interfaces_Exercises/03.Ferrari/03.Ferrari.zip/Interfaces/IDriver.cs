﻿public interface IDriver
{
    string Name { get; }
}