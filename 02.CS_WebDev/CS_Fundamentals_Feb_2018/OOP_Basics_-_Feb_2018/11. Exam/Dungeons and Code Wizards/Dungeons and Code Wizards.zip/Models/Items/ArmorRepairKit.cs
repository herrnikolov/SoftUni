﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Models.Bags
{
    public class ArmorRepairKit : Item
    {
        public ArmorRepairKit(int weight) : base(weight = 10)
        {

        }
    }
}
