﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Models.Bags
{
    public class PoisonPotion : Item
    {
        public PoisonPotion(int weight) : base(weight = 5)
        {
        }
    }
}
