﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Models.Character
{
    public enum Faction
    {
        CSharp, Java
    }
}
