﻿namespace _04._Online_Radio_Database
{
    internal class InvalidSongNameException : InvalidSongException
    {
        public override string Message => "Song name should be between 3 and 30 symbols.";
    }
}
