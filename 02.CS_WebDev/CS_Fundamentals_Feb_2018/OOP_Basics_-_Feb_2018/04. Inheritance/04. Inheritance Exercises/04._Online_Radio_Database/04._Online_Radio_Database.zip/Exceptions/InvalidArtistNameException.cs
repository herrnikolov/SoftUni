﻿namespace _04._Online_Radio_Database
{
    internal class InvalidArtistNameException : InvalidSongException
    {
        public override string Message => "Artist name should be between 3 and 20 symbols.";
    }
}
