﻿namespace _04._Online_Radio_Database
{
    internal class InvalidSongSecondsException : InvalidSongLengthException
    {
        public override string Message => "Song seconds should be between 0 and 59.";
    }
}
