﻿namespace ForumSystem.Services.Models.Reply
{
    public class ReplyServiceModel
    {
        public int PostId { get; set; }

        public string Author { get; set; }

        public string Content { get; set; }
    }
}
