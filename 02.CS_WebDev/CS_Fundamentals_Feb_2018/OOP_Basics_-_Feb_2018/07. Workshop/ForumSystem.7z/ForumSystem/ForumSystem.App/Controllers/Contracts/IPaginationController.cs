﻿namespace ForumSystem.App.Controllers.Contracts
{
    public interface IPaginationController
    {
        int CurrentPage { get; set; }
    }
}
