﻿namespace ForumSystem.App
{
    public interface IPositionable
    {
        Position Position { get; }
    }
}
