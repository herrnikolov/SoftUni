﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace _05._Slicing_File
{
    class Program
    {
        private const string SourseFilePath = "../sliceMe.mp4";
        private const string DestinationDirectoryPath = "../";
        private static List<string> piecesPaths;
        private static readonly string extension = SourseFilePath.Split('.').Last();
        static void Main(string[] args)
        {
            Console.Write("How many pieces: ");

            var pieces = int.Parse(Console.ReadLine());

            piecesPaths = new List<string>();

            Slice(SourseFilePath, pieces);

            Assemble(piecesPaths);
        }

        private static void Slice(string soursePath, int pieces)
        {
            if (!Directory.Exists(DestinationDirectoryPath))
            {
                Directory.CreateDirectory(DestinationDirectoryPath);
            }

            using (var reader = new FileStream(soursePath, FileMode.Open, FileAccess.Read))
            {
                var sizePerPiece = (uint)(Math.Ceiling((double)reader.Length / pieces));

                for (int piece = 1; piece <= pieces; piece++)
                {
                    using (var writer = new FileStream(DestinationDirectoryPath + $"Part-{piece}.{extension}", FileMode.Create))
                    {
                        byte[] buffer = new byte[sizePerPiece];
                        int readBytes = reader.Read(buffer, 0, buffer.Length);
                        writer.Write(buffer, 0, readBytes);
                        piecesPaths.Add(DestinationDirectoryPath + $"Part-{piece}.{extension}");
                    }
                }
            }
        }

        private static void Assemble(List<string> piecesPaths)
        {
            for (int piece = 0; piece < piecesPaths.Count; piece++)
            {
                using (FileStream reader = new FileStream(piecesPaths[piece], FileMode.Open))
                {
                    using (FileStream writer = new FileStream(DestinationDirectoryPath + $"assembled.{extension}", FileMode.Append))
                    {
                        byte[] buffer = new byte[reader.Length];
                        int readBytes = reader.Read(buffer, 0, buffer.Length);
                        writer.Write(buffer, 0, readBytes);
                    }
                }
            }
        }
    }
}
