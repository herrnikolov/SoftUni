#!/bin/bash

sudo yum install -y java-1.8.0-openjdk
