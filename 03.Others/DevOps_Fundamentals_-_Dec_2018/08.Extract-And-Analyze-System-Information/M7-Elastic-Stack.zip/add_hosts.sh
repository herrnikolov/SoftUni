#!/bin/bash

echo "192.168.99.101 server" >> /etc/hosts
echo "192.168.99.102 node1" >> /etc/hosts
echo "192.168.99.103 node2" >> /etc/hosts
echo "192.168.99.104 docker" >> /etc/hosts

