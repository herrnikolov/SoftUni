#!/bin/bash

# install EPEL
yum install -y epel-release
