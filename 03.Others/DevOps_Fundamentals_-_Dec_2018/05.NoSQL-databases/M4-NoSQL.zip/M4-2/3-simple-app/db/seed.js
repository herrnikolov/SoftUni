db.createCollection('counters');
db.counters.insert({counter: "visits", total: 0});
