#!/bin/bash

echo "192.168.99.100 salt-server.sulab salt-server" >> /etc/hosts
echo "192.168.99.101 salt-client-1.sulab salt-client-1" >> /etc/hosts
echo "192.168.99.102 salt-client-2.sulab salt-client-2" >> /etc/hosts
