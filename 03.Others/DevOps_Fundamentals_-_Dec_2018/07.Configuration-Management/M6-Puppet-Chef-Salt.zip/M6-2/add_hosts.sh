#!/bin/bash

echo "192.168.99.100 chef-server.sulab chef-server" >> /etc/hosts
echo "192.168.99.101 chef-client-1.sulab chef-client-1" >> /etc/hosts
echo "192.168.99.102 chef-client-2.sulab chef-client-2" >> /etc/hosts
echo "192.168.99.105 chef-dk.sulab chef-dk" >> /etc/hosts
