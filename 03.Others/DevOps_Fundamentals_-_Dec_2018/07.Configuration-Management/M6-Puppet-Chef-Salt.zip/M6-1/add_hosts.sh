#!/bin/bash

echo "192.168.99.100 puppet-server.sulab puppet-server" >> /etc/hosts
echo "192.168.99.101 puppet-client-1.sulab puppet-client-1" >> /etc/hosts
echo "192.168.99.102 puppet-client-2.sulab puppet-client-2" >> /etc/hosts
