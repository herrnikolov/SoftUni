﻿namespace DOMBuilder
{
    public class Program
    {
        public static void Main()
        {
        }
    }
}
