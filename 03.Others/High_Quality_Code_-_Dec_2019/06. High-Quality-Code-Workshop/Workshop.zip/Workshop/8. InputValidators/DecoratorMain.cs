﻿namespace InputValidaotrs
{
    public class DecoratorMain
    {
        public static void Main()
        {
        }
    }
}
