﻿namespace InputValidaotrs.Interfaces
{
    public interface IValidator
    {
        bool Validate(string input);
    }
}