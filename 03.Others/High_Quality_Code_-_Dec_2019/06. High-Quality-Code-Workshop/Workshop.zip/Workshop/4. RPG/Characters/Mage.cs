﻿namespace RPG.Characters
{
    public class Mage
    {
        public Mage()
        {
        }
    }
}
