﻿namespace RPG.Characters
{
    public class Warrior
    {
        public Warrior()
        {
        }
    }
}
