﻿namespace RPG.Weapons
{
    public class Sword
    {
    }
}
