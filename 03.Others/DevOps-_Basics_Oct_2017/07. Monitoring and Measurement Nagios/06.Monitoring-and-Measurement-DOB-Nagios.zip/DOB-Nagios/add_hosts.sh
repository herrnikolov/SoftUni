#!/bin/bash

echo "192.168.82.100 master.sulab.local master" >> /etc/hosts
echo "192.168.82.101 node1.sulab.local node1" >> /etc/hosts
echo "192.168.82.102 node2.sulab.local node2" >> /etc/hosts
