#!/bin/bash

sudo rm $(which docker)
