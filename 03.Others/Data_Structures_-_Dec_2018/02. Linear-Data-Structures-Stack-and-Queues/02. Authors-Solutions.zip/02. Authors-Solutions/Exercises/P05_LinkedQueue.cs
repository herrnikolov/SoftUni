﻿using System;
public class P05_LinkedQueue<T> 
    where T : IComparable
{
    private QueueNode<T> head;
    private QueueNode<T> tail;

    public int Count { get; private set; }

    public void Enqueue(T element)
    {
        QueueNode<T> node = new QueueNode<T>(element, this.tail);

        if (this.head == null)
        {
            this.head = this.tail = node;
        }
        else
        {
            this.tail.NextNode = node;
            this.tail = this.tail.NextNode;
        }

        
        this.Count++;
    }

    public T Dequeue()
    {
        if (this.head == null)
        {
            throw new InvalidOperationException("Queue is empty");
        }

        T result = this.head.Value;
        this.head = this.head.NextNode;
        this.Count--;

        return result;
    }

    public T[] ToArray()
    {
        T[] arr = new T[this.Count];
        QueueNode<T> node = this.head;
        int index = 0;

        while (node != null)
        {
            arr[index++] = node.Value;
            node = node.NextNode;
        }

        return arr;
    }

    private class QueueNode<T>
    {
        public T Value { get; }
        public QueueNode<T> NextNode { get; set; }
        public QueueNode<T> PrevNode { get; set; }

        public QueueNode(T value, QueueNode<T> prev)
        {
            this.Value = value;
            this.PrevNode = prev;
        }
    }
}