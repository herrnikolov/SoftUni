﻿using System;
using System.Linq;

public class P03_ArrayStack<T>
    where T : IComparable
{
    private T[] elements;

    public int Count { get; private set; }

    private const int InitialCapacity = 16;

    public ArrayStack(int capacity = InitialCapacity)
    {
        this.elements = new T[capacity];
        this.Count = 0;
    }

    public void Push(T element)
    {
        if (this.Count == this.elements.Length)
        {
            this.Grow();
        }

        this.elements[this.Count] = element;
        this.Count++;
    }

    public T Pop()
    {
        if (this.Count == 0)
        {
            throw new InvalidOperationException();
        }

        this.Count--;
        T element = this.elements[this.Count];

        return element;
    }

    public T[] ToArray()
    {
        T[] result = new T[this.Count];

        Array.Copy(this.elements, 0, result, 0, this.Count);

        return result.Reverse().ToArray();
    }

    private void Grow()
    {
        T[] newArr = new T[this.elements.Length * 2];

        Array.Copy(this.elements, 0, newArr, 0, this.Count);

        this.elements = newArr;
    }
}
