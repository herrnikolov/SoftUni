﻿using System;
using System.Collections.Generic;

public class P02_CalculateSequence
{
    public static void Main()
    {
       CalcSeq(5);
    }

    private static int[] CalcSeq(int n)
    {
        Queue<int> queue = new Queue<int>();
        queue.Enqueue(n);
        Queue<int> result = new Queue<int>();

        for (int i = 0; i < 50; i++)
        {
            int curr = queue.Dequeue();
            result.Enqueue(curr);

            int first = curr + 1;
            int second = 2 * curr + 1;
            int third = 2 + curr;

            queue.Enqueue(first);
            queue.Enqueue(second);
            queue.Enqueue(third);
        }

        return result.ToArray();

    }
}