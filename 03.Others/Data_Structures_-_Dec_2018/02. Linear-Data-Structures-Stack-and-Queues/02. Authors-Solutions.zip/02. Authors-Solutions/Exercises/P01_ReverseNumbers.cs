﻿using System;
using System.Collections.Generic;

public class P01_ReverseNumbers
{
    public static void Main()
    {
        ReverseNumbers(new int[] {2, 3, 4, 5});
    }
	
    private static int[] ReverseNumbers(int[] nums)
    {
        Stack<int> stack = new Stack<int>(nums);

        return stack.ToArray();
    }
}