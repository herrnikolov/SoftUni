﻿using System;
using System.Collections.Generic;

public class P06_SequenceNM
{
    public static void Main()
    {
        MnSeq(3, 10);
    }

    private static void MnSeq(int n, int m)
    {
        Queue<Item> nums = new Queue<Item>();
        
        nums.Enqueue(new Item(n, null));

        while (nums.Count != 0)
        {
            Item current = nums.Dequeue();

            if (current.Value < m)
            {
                nums.Enqueue(new Item(current.Value + 1, current));
                nums.Enqueue(new Item(current.Value + 2, current));
                nums.Enqueue(new Item(current.Value * 2, current));
            }
            else if (current.Value == m)
            {
                Stack<int> result = new Stack<int>();
                while (current != null)
                {
                    result.Push(current.Value);
                    current = current.PreviousItem;
                }

                Console.WriteLine(string.Join(" -> ", result));
                return;
            }
        }
    }

    private class Item
    {
        public Item(int n, Item previousItem)
        {
            this.Value = n;
            this.PreviousItem = previousItem;
        }

        public int Value { get; set; }
        public Item PreviousItem { get; set; }
    }
}