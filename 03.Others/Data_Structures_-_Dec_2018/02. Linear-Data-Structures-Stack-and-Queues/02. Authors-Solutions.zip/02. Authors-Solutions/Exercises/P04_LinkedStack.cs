﻿using System;

public class P04_LinkedStack<T> 
    where T : IComparable
{
    private Node<T> head;

    public int Count { get; private set; }

    public void Push(T element)
    {
        this.head = new Node<T>(element, this.head);
        this.Count++;
    }

    public T Pop()
    {
        if (this.Count == 0)
        {
            throw new InvalidOperationException("The stack is empty");
        }
        Node<T> node = this.head;
        this.head = this.head.NextNode;
        this.Count--;

        return node.Value;
    }

    public T[] ToArray()
    {
        T[] arr = new T[this.Count];

        int pos = 0;
        Node<T> curr;

        while ((curr = this.head) != null)
        {
            arr[pos++] = curr.Value;
            this.head = this.head.NextNode;
        }

        return arr;
    }

    private class Node<T>
    {   
        public T Value { get; }
        public Node<T> NextNode { get; set; }

        public Node(T value, Node<T> nextNode = null)
        {
            this.Value = value;
            this.NextNode = nextNode;
        }
    }

}