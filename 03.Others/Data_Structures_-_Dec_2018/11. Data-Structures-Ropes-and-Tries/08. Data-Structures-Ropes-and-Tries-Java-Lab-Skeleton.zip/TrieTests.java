import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;

import static org.junit.Assert.assertEquals;

public class TrieTests {
    @Test
    public void insert_Contains_Single_NoMatches() {
        Trie<Integer> trie = new Trie<>();
        trie.insert("Andy", 25);

        boolean a = trie.contains("A");
        Assert.assertFalse(a);
    }

    @Test
    public void insert_Contains_Single_Match() {
        Trie<Integer> trie = new Trie<>();
        trie.insert("Andy", 25);

        Assert.assertTrue(trie.contains("Andy"));
    }

    @Test
    public void insert_Contains_Multiple() {
        Trie<Integer> trie = new Trie<>();
        trie.insert("A", 25);
        trie.insert("AA", 25);
        trie.insert("AAA", 25);

        Assert.assertTrue(trie.contains("A"));
        Assert.assertTrue(trie.contains("AA"));
        Assert.assertTrue(trie.contains("AAA"));
    }

    @Test
    public void getByPrefix_SingleCharPrefix_NoMatches() {
        Trie<Integer> trie = new Trie<>();
        trie.insert("Andy", 25);

        ArrayList<String> expected = new ArrayList<>();
        Iterable<String> actual = trie.getByPrefix("Z");

        Assert.assertTrue(areCollectionsEqual(expected, actual));
    }

    @Test
    public void getByPrefix_SingleCharPrefix_SingleMatch() {
        Trie<Integer> trie = new Trie<>();
        trie.insert("Andy", 25);

        ArrayList<String> expected = new ArrayList<>();
        expected.add("Andy");

        Iterable<String> actual = trie.getByPrefix("Andy");

        Assert.assertTrue(areCollectionsEqual(expected, actual));
    }

    @Test
    public void getByPrefix_SingleCharPrefix_MultipleMatches() {
        Trie<Integer> trie = new Trie<>();
        trie.insert("Andy", 25);
        trie.insert("Amy", 8);
        trie.insert("Adam", 12);
        trie.insert("Bill", 13);

        ArrayList<String> expected = new ArrayList<>();
        expected.add("Andy");
        expected.add("Amy");
        expected.add("Adam");

        Iterable<String> actual = trie.getByPrefix("A");

        Assert.assertTrue(areCollectionsEqual(expected, actual));
    }

    @Test
    public void getByPrefix_TwoCharPrefix_SingleMatch() {
        Trie<Integer> trie = new Trie<>();
        trie.insert("Andy", 25);

        ArrayList<String> expected = new ArrayList<>();
        expected.add("Andy");

        Iterable<String> actual = trie.getByPrefix("An");

        Assert.assertTrue(areCollectionsEqual(expected, actual));
    }

    @Test
    public void getByPrefix_TwoCharPrefix_MultipleMatches() {
        Trie<Integer> trie = new Trie<>();
        trie.insert("Andy", 25);
        trie.insert("Andy M", 8);
        trie.insert("Adam", 12);
        trie.insert("Bill", 13);

        ArrayList<String> expected = new ArrayList<>();
        expected.add("Andy");
        expected.add("Andy M");

        Iterable<String> actual = trie.getByPrefix("An");

        Assert.assertTrue(areCollectionsEqual(expected, actual));
    }

    @Test
    public void getValue_Single() {
        Trie<Integer> trie = new Trie<>();
        trie.insert("Andy", 25);

        assertEquals((Integer) 25, trie.getValue("Andy"));
    }

    @Test
    public void getValue_Multiple() {
        Trie<Integer> trie = new Trie<>();
        trie.insert("Andy", 25);
        trie.insert("Andy M", 8);
        trie.insert("Adam", 12);
        trie.insert("Bill", 13);

        ArrayList<Integer> expected = new ArrayList<>();
        expected.add(25);
        expected.add(8);
        expected.add(12);
        expected.add(13);

        Iterable<String> keys = trie.getByPrefix("");
        int index = 0;
        for (String key : keys) {
            assertEquals(expected.get(index++), trie.getValue(key));
        }
    }

    private static boolean areCollectionsEqual(Iterable<String> a, Iterable<String> b) {
        Iterator<String> aIterator = a.iterator();
        Iterator<String> bIterator = b.iterator();

        while (aIterator.hasNext()) {
            if (!bIterator.hasNext()) {
                return false;
            }

            if (!Objects.equals(aIterator.next(), bIterator.next())) {
                return false;
            }
        }

        return true;
    }
}
