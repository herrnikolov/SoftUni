#!/bin/bash

# Tenant ID (tenant)
export AZURE_TENANT_ID='put-your-id-here'

# Application ID (appId)
export AZURE_CLIENT_ID='put-your-id-here'

# Password (password)
export AZURE_CLIENT_SECRET='put-your-id-here'

# Subscription
export AZURE_SUBSCRIPTION_ID='put-your-id-here'
