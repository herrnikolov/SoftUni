#!/bin/bash

echo "192.168.82.100 master.sulab.local master" >> /etc/hosts
echo "192.168.82.101 client.sulab.local client" >> /etc/hosts
echo "192.168.82.102 slave.sulab.local slave" >> /etc/hosts
