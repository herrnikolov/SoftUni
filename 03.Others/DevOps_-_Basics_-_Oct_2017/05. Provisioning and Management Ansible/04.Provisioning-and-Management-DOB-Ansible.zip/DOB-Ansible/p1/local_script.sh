#!/bin/bash

echo 'My hostname is '$HOSTNAME
