<?php

/* @Twig/layout.html.twig */
class __TwigTemplate_0ef46ff3e00be850b375145c4de69a72941605b1b30816a42d1a36aa92bc080f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f34258124d3366b5822b444fdb99e36ad7776222f439b4cdd88e8e2a0d38385e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f34258124d3366b5822b444fdb99e36ad7776222f439b4cdd88e8e2a0d38385e->enter($__internal_f34258124d3366b5822b444fdb99e36ad7776222f439b4cdd88e8e2a0d38385e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/layout.html.twig"));

        $__internal_78b575787822755ed6e98f7ad0d92d366da92d4a53726fa4345165dbce39816b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_78b575787822755ed6e98f7ad0d92d366da92d4a53726fa4345165dbce39816b->enter($__internal_78b575787822755ed6e98f7ad0d92d366da92d4a53726fa4345165dbce39816b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"icon\" type=\"image/png\" href=\"";
        // line 8
        echo twig_include($this->env, $context, "@Twig/images/favicon.png.base64");
        echo "\">
        <style>";
        // line 9
        echo twig_include($this->env, $context, "@Twig/exception.css.twig");
        echo "</style>
        ";
        // line 10
        $this->displayBlock('head', $context, $blocks);
        // line 11
        echo "    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">";
        // line 15
        echo twig_include($this->env, $context, "@Twig/images/symfony-logo.svg");
        echo " Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">";
        // line 19
        echo twig_include($this->env, $context, "@Twig/images/icon-book.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">";
        // line 26
        echo twig_include($this->env, $context, "@Twig/images/icon-support.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        ";
        // line 33
        $this->displayBlock('body', $context, $blocks);
        // line 34
        echo "        ";
        echo twig_include($this->env, $context, "@Twig/base_js.html.twig");
        echo "
    </body>
</html>
";
        
        $__internal_f34258124d3366b5822b444fdb99e36ad7776222f439b4cdd88e8e2a0d38385e->leave($__internal_f34258124d3366b5822b444fdb99e36ad7776222f439b4cdd88e8e2a0d38385e_prof);

        
        $__internal_78b575787822755ed6e98f7ad0d92d366da92d4a53726fa4345165dbce39816b->leave($__internal_78b575787822755ed6e98f7ad0d92d366da92d4a53726fa4345165dbce39816b_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_d34981d361c6e7d56b5bb2af6f4ca1e61d7c44a4a0ed114cb6de99cf0da8d5c7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d34981d361c6e7d56b5bb2af6f4ca1e61d7c44a4a0ed114cb6de99cf0da8d5c7->enter($__internal_d34981d361c6e7d56b5bb2af6f4ca1e61d7c44a4a0ed114cb6de99cf0da8d5c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_b162c07a1d9b9cb76af90800859d56dd8c81e937f010d97fcac8233cdf1a6794 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b162c07a1d9b9cb76af90800859d56dd8c81e937f010d97fcac8233cdf1a6794->enter($__internal_b162c07a1d9b9cb76af90800859d56dd8c81e937f010d97fcac8233cdf1a6794_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_b162c07a1d9b9cb76af90800859d56dd8c81e937f010d97fcac8233cdf1a6794->leave($__internal_b162c07a1d9b9cb76af90800859d56dd8c81e937f010d97fcac8233cdf1a6794_prof);

        
        $__internal_d34981d361c6e7d56b5bb2af6f4ca1e61d7c44a4a0ed114cb6de99cf0da8d5c7->leave($__internal_d34981d361c6e7d56b5bb2af6f4ca1e61d7c44a4a0ed114cb6de99cf0da8d5c7_prof);

    }

    // line 10
    public function block_head($context, array $blocks = array())
    {
        $__internal_0be10810e0074406de4c04f9e21401876f20da4ad3647dea504c92c7dbc42c4a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0be10810e0074406de4c04f9e21401876f20da4ad3647dea504c92c7dbc42c4a->enter($__internal_0be10810e0074406de4c04f9e21401876f20da4ad3647dea504c92c7dbc42c4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_4ac715d41962cabfaa5062e7f52d9aa1f68c6ae210f8881692cde1e0841901b0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4ac715d41962cabfaa5062e7f52d9aa1f68c6ae210f8881692cde1e0841901b0->enter($__internal_4ac715d41962cabfaa5062e7f52d9aa1f68c6ae210f8881692cde1e0841901b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        
        $__internal_4ac715d41962cabfaa5062e7f52d9aa1f68c6ae210f8881692cde1e0841901b0->leave($__internal_4ac715d41962cabfaa5062e7f52d9aa1f68c6ae210f8881692cde1e0841901b0_prof);

        
        $__internal_0be10810e0074406de4c04f9e21401876f20da4ad3647dea504c92c7dbc42c4a->leave($__internal_0be10810e0074406de4c04f9e21401876f20da4ad3647dea504c92c7dbc42c4a_prof);

    }

    // line 33
    public function block_body($context, array $blocks = array())
    {
        $__internal_b2a25466f44d46d4c36a4e069a5a450a7d2425ed007fc2ef5b6887d33fc38cbb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b2a25466f44d46d4c36a4e069a5a450a7d2425ed007fc2ef5b6887d33fc38cbb->enter($__internal_b2a25466f44d46d4c36a4e069a5a450a7d2425ed007fc2ef5b6887d33fc38cbb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f074ef5b1bd702991c67efb9231107ec2a1cf9e1104fedbd9fb30797d3e26b87 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f074ef5b1bd702991c67efb9231107ec2a1cf9e1104fedbd9fb30797d3e26b87->enter($__internal_f074ef5b1bd702991c67efb9231107ec2a1cf9e1104fedbd9fb30797d3e26b87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_f074ef5b1bd702991c67efb9231107ec2a1cf9e1104fedbd9fb30797d3e26b87->leave($__internal_f074ef5b1bd702991c67efb9231107ec2a1cf9e1104fedbd9fb30797d3e26b87_prof);

        
        $__internal_b2a25466f44d46d4c36a4e069a5a450a7d2425ed007fc2ef5b6887d33fc38cbb->leave($__internal_b2a25466f44d46d4c36a4e069a5a450a7d2425ed007fc2ef5b6887d33fc38cbb_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 33,  120 => 10,  103 => 7,  88 => 34,  86 => 33,  76 => 26,  66 => 19,  59 => 15,  53 => 11,  51 => 10,  47 => 9,  43 => 8,  39 => 7,  33 => 4,  28 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"{{ _charset }}\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>{% block title %}{% endblock %}</title>
        <link rel=\"icon\" type=\"image/png\" href=\"{{ include('@Twig/images/favicon.png.base64') }}\">
        <style>{{ include('@Twig/exception.css.twig') }}</style>
        {% block head %}{% endblock %}
    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">{{ include('@Twig/images/symfony-logo.svg') }} Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-book.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-support.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        {% block body %}{% endblock %}
        {{ include('@Twig/base_js.html.twig') }}
    </body>
</html>
", "@Twig/layout.html.twig", "F:\\00. Work\\Software-Technologies-Exam-Prep-III\\Solutions\\PHP Skeleton\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\layout.html.twig");
    }
}
