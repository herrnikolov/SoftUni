<?php

/* film/delete.html.twig */
class __TwigTemplate_65d25cda53d0b41c3feb9360ce8286904bf6e18104d433dcf7a0814b5d46bd9f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "film/delete.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0dda35c9408e66a3cca2b4d5f919107d3de486e226bc65e8f6ff5c09683762a1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0dda35c9408e66a3cca2b4d5f919107d3de486e226bc65e8f6ff5c09683762a1->enter($__internal_0dda35c9408e66a3cca2b4d5f919107d3de486e226bc65e8f6ff5c09683762a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "film/delete.html.twig"));

        $__internal_a2f710b714ccb72519796d05228004a2873014f6a003176129d6e917e18373ce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a2f710b714ccb72519796d05228004a2873014f6a003176129d6e917e18373ce->enter($__internal_a2f710b714ccb72519796d05228004a2873014f6a003176129d6e917e18373ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "film/delete.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0dda35c9408e66a3cca2b4d5f919107d3de486e226bc65e8f6ff5c09683762a1->leave($__internal_0dda35c9408e66a3cca2b4d5f919107d3de486e226bc65e8f6ff5c09683762a1_prof);

        
        $__internal_a2f710b714ccb72519796d05228004a2873014f6a003176129d6e917e18373ce->leave($__internal_a2f710b714ccb72519796d05228004a2873014f6a003176129d6e917e18373ce_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_fe6a68b7da4c2c934029afb05999170339f62085183cbc25f20191a9400b2852 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fe6a68b7da4c2c934029afb05999170339f62085183cbc25f20191a9400b2852->enter($__internal_fe6a68b7da4c2c934029afb05999170339f62085183cbc25f20191a9400b2852_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_407358c63cda5b726ac9f8f100244f3f4d2ac329e52bfb158b9ec6664b7af66d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_407358c63cda5b726ac9f8f100244f3f4d2ac329e52bfb158b9ec6664b7af66d->enter($__internal_407358c63cda5b726ac9f8f100244f3f4d2ac329e52bfb158b9ec6664b7af66d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "    <h1>Delete Film</h1>
    <section>
        <form method=\"POST\">
            <div>
                <label for=\"name\">Name</label>
                <input type=\"text\" id=\"name\" value=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute(($context["film"] ?? $this->getContext($context, "film")), "name", array()), "html", null, true);
        echo "\" name=\"film[name]\" disabled />
                <label for=\"genre\">Genre</label>
                <input type=\"text\" id=\"genre\" value=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute(($context["film"] ?? $this->getContext($context, "film")), "genre", array()), "html", null, true);
        echo "\" name=\"film[genre]\" disabled />
                <label for=\"director\">Director</label>
                <input type=\"text\" id=\"director\" value=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute(($context["film"] ?? $this->getContext($context, "film")), "director", array()), "html", null, true);
        echo "\" name=\"film[director]\" disabled />
                <label for=\"year\">Year</label>
                <input type=\"text\" id=\"year\" value=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute(($context["film"] ?? $this->getContext($context, "film")), "year", array()), "html", null, true);
        echo "\" name=\"film[year]\" disabled />

                ";
        // line 17
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'row');
        echo "

                <button type=\"submit\" class=\"accept\">Delete</button>
                <button type=\"button\" onclick=\"location.href='/'\" class=\"cancel\">Cancel</button>
            </div>
        </form>
    </section>
";
        
        $__internal_407358c63cda5b726ac9f8f100244f3f4d2ac329e52bfb158b9ec6664b7af66d->leave($__internal_407358c63cda5b726ac9f8f100244f3f4d2ac329e52bfb158b9ec6664b7af66d_prof);

        
        $__internal_fe6a68b7da4c2c934029afb05999170339f62085183cbc25f20191a9400b2852->leave($__internal_fe6a68b7da4c2c934029afb05999170339f62085183cbc25f20191a9400b2852_prof);

    }

    public function getTemplateName()
    {
        return "film/delete.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 17,  71 => 15,  66 => 13,  61 => 11,  56 => 9,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
    <h1>Delete Film</h1>
    <section>
        <form method=\"POST\">
            <div>
                <label for=\"name\">Name</label>
                <input type=\"text\" id=\"name\" value=\"{{ film.name }}\" name=\"film[name]\" disabled />
                <label for=\"genre\">Genre</label>
                <input type=\"text\" id=\"genre\" value=\"{{ film.genre }}\" name=\"film[genre]\" disabled />
                <label for=\"director\">Director</label>
                <input type=\"text\" id=\"director\" value=\"{{ film.director }}\" name=\"film[director]\" disabled />
                <label for=\"year\">Year</label>
                <input type=\"text\" id=\"year\" value=\"{{ film.year }}\" name=\"film[year]\" disabled />

                {{ form_row(form._token) }}

                <button type=\"submit\" class=\"accept\">Delete</button>
                <button type=\"button\" onclick=\"location.href='/'\" class=\"cancel\">Cancel</button>
            </div>
        </form>
    </section>
{% endblock %}", "film/delete.html.twig", "F:\\00. Work\\Software-Technologies-Exam-Prep-III\\Solutions\\PHP Skeleton\\app\\Resources\\views\\film\\delete.html.twig");
    }
}
