<?php

/* film/index.html.twig */
class __TwigTemplate_6ea26922b3f615ba99ae213a268e556f5b86e2a98a7a57f7d3c04f0c4d3cc4d8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "film/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_598df69cd04004525bf01c01ab65ca990ca409df7510f4bb7910ff2ddc1b4643 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_598df69cd04004525bf01c01ab65ca990ca409df7510f4bb7910ff2ddc1b4643->enter($__internal_598df69cd04004525bf01c01ab65ca990ca409df7510f4bb7910ff2ddc1b4643_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "film/index.html.twig"));

        $__internal_e213e56ec823f9c5f1591ad5c3cd9bed47392a07d0daf6530909199c3bd44c17 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e213e56ec823f9c5f1591ad5c3cd9bed47392a07d0daf6530909199c3bd44c17->enter($__internal_e213e56ec823f9c5f1591ad5c3cd9bed47392a07d0daf6530909199c3bd44c17_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "film/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_598df69cd04004525bf01c01ab65ca990ca409df7510f4bb7910ff2ddc1b4643->leave($__internal_598df69cd04004525bf01c01ab65ca990ca409df7510f4bb7910ff2ddc1b4643_prof);

        
        $__internal_e213e56ec823f9c5f1591ad5c3cd9bed47392a07d0daf6530909199c3bd44c17->leave($__internal_e213e56ec823f9c5f1591ad5c3cd9bed47392a07d0daf6530909199c3bd44c17_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_c2d7d5889b5f038e3555d2b92ad20699b3de8c20caa0d67637ee9c22d0826e73 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c2d7d5889b5f038e3555d2b92ad20699b3de8c20caa0d67637ee9c22d0826e73->enter($__internal_c2d7d5889b5f038e3555d2b92ad20699b3de8c20caa0d67637ee9c22d0826e73_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_1e203a22f32b6b59632e6cfd1dc3299679ec5dbddaef36500e30c45a201bace9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1e203a22f32b6b59632e6cfd1dc3299679ec5dbddaef36500e30c45a201bace9->enter($__internal_1e203a22f32b6b59632e6cfd1dc3299679ec5dbddaef36500e30c45a201bace9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "<h1>All Films</h1>

<div>
    <button class=\"add-new\" onclick=\"location.href='/create'\">Create New Film</button>
</div>

<section>
    <div>
        <table>
            <tr>
                <th>Name</th>
                <th>Genre</th>
                <th>Director</th>
                <th>Year</th>
                <th>Actions</th>
            </tr>
            ";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["films"] ?? $this->getContext($context, "films")));
        foreach ($context['_seq'] as $context["_key"] => $context["film"]) {
            // line 21
            echo "            <tr>
                <td>";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["film"], "name", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["film"], "genre", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["film"], "director", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["film"], "year", array()), "html", null, true);
            echo "</td>
                <td>
                    <button onclick=\"location.href='/edit/";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["film"], "id", array()), "html", null, true);
            echo "'\" class=\"edit\">Edit</button>
                    <button onclick=\"location.href='/delete/";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["film"], "id", array()), "html", null, true);
            echo "'\" class=\"delete\">Delete</button>
                </td>
            </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['film'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "        </table>
    </div>
</section>
";
        
        $__internal_1e203a22f32b6b59632e6cfd1dc3299679ec5dbddaef36500e30c45a201bace9->leave($__internal_1e203a22f32b6b59632e6cfd1dc3299679ec5dbddaef36500e30c45a201bace9_prof);

        
        $__internal_c2d7d5889b5f038e3555d2b92ad20699b3de8c20caa0d67637ee9c22d0826e73->leave($__internal_c2d7d5889b5f038e3555d2b92ad20699b3de8c20caa0d67637ee9c22d0826e73_prof);

    }

    public function getTemplateName()
    {
        return "film/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 32,  95 => 28,  91 => 27,  86 => 25,  82 => 24,  78 => 23,  74 => 22,  71 => 21,  67 => 20,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
<h1>All Films</h1>

<div>
    <button class=\"add-new\" onclick=\"location.href='/create'\">Create New Film</button>
</div>

<section>
    <div>
        <table>
            <tr>
                <th>Name</th>
                <th>Genre</th>
                <th>Director</th>
                <th>Year</th>
                <th>Actions</th>
            </tr>
            {% for film in films %}
            <tr>
                <td>{{ film.name }}</td>
                <td>{{ film.genre }}</td>
                <td>{{ film.director }}</td>
                <td>{{ film.year }}</td>
                <td>
                    <button onclick=\"location.href='/edit/{{ film.id }}'\" class=\"edit\">Edit</button>
                    <button onclick=\"location.href='/delete/{{ film.id }}'\" class=\"delete\">Delete</button>
                </td>
            </tr>
            {% endfor %}
        </table>
    </div>
</section>
{% endblock %}", "film/index.html.twig", "F:\\00. Work\\Software-Technologies-Exam-Prep-III\\Solutions\\PHP Skeleton\\app\\Resources\\views\\film\\index.html.twig");
    }
}
