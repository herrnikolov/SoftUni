<?php

/* film/create.html.twig */
class __TwigTemplate_009a3431b9c1c7980acb206521572a7ee7f2371c50f7fdf88da4a9578275933e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "film/create.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8dbd131f87576fd40b0c614f179d9f337db937785a99ee3b49f956c09a558349 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8dbd131f87576fd40b0c614f179d9f337db937785a99ee3b49f956c09a558349->enter($__internal_8dbd131f87576fd40b0c614f179d9f337db937785a99ee3b49f956c09a558349_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "film/create.html.twig"));

        $__internal_c1e957a97cdb414c4f9e62bc19666b2010b552aec427d4c144c025558d42c631 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c1e957a97cdb414c4f9e62bc19666b2010b552aec427d4c144c025558d42c631->enter($__internal_c1e957a97cdb414c4f9e62bc19666b2010b552aec427d4c144c025558d42c631_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "film/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8dbd131f87576fd40b0c614f179d9f337db937785a99ee3b49f956c09a558349->leave($__internal_8dbd131f87576fd40b0c614f179d9f337db937785a99ee3b49f956c09a558349_prof);

        
        $__internal_c1e957a97cdb414c4f9e62bc19666b2010b552aec427d4c144c025558d42c631->leave($__internal_c1e957a97cdb414c4f9e62bc19666b2010b552aec427d4c144c025558d42c631_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_add8558cdc67667a95a9ace1dd799e29a61c32cb16f597a2949dbfa6114f49c5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_add8558cdc67667a95a9ace1dd799e29a61c32cb16f597a2949dbfa6114f49c5->enter($__internal_add8558cdc67667a95a9ace1dd799e29a61c32cb16f597a2949dbfa6114f49c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_5a86477aa4020ba05a4754cf9d48a39efcfcdb6d59c90b9260aed5f5814e954c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a86477aa4020ba05a4754cf9d48a39efcfcdb6d59c90b9260aed5f5814e954c->enter($__internal_5a86477aa4020ba05a4754cf9d48a39efcfcdb6d59c90b9260aed5f5814e954c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "<h1>Create Film</h1>
<section>
    <form method=\"POST\">
        <div>
            <label for=\"name\">Name</label>
            <input type=\"text\" id=\"name\" name=\"film[name]\" />
            <label for=\"genre\">Genre</label>
            <input type=\"text\" id=\"genre\" name=\"film[genre]\" />
            <label for=\"director\">Director</label>
            <input type=\"text\" id=\"director\" name=\"film[director]\" />
            <label for=\"year\">Year</label>
            <input type=\"text\" id=\"year\" name=\"film[year]\" />

            ";
        // line 17
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'row');
        echo "

            <button type=\"submit\" class=\"accept\">Create</button>
            <button type=\"button\" onclick=\"location.href='/'\" class=\"cancel\">Cancel</button>
        </div>
    </form>
</section>
";
        
        $__internal_5a86477aa4020ba05a4754cf9d48a39efcfcdb6d59c90b9260aed5f5814e954c->leave($__internal_5a86477aa4020ba05a4754cf9d48a39efcfcdb6d59c90b9260aed5f5814e954c_prof);

        
        $__internal_add8558cdc67667a95a9ace1dd799e29a61c32cb16f597a2949dbfa6114f49c5->leave($__internal_add8558cdc67667a95a9ace1dd799e29a61c32cb16f597a2949dbfa6114f49c5_prof);

    }

    public function getTemplateName()
    {
        return "film/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  64 => 17,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
<h1>Create Film</h1>
<section>
    <form method=\"POST\">
        <div>
            <label for=\"name\">Name</label>
            <input type=\"text\" id=\"name\" name=\"film[name]\" />
            <label for=\"genre\">Genre</label>
            <input type=\"text\" id=\"genre\" name=\"film[genre]\" />
            <label for=\"director\">Director</label>
            <input type=\"text\" id=\"director\" name=\"film[director]\" />
            <label for=\"year\">Year</label>
            <input type=\"text\" id=\"year\" name=\"film[year]\" />

            {{ form_row(form._token) }}

            <button type=\"submit\" class=\"accept\">Create</button>
            <button type=\"button\" onclick=\"location.href='/'\" class=\"cancel\">Cancel</button>
        </div>
    </form>
</section>
{% endblock %}", "film/create.html.twig", "F:\\00. Work\\Software-Technologies-Exam-Prep-III\\Solutions\\PHP Skeleton\\app\\Resources\\views\\film\\create.html.twig");
    }
}
