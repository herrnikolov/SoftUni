package teistermask.bindingModel;

public class FilmBindingModel {
	//TODO: Implement me ...
}
