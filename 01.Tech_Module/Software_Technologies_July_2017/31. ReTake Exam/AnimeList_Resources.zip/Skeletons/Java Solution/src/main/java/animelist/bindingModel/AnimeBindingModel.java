package animelist.bindingModel;

public class AnimeBindingModel {
    //TODO: Implement me ...
}
