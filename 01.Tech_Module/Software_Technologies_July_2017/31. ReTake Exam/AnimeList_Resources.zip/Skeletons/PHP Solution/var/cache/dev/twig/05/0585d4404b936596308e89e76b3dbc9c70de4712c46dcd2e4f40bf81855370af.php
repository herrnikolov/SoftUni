<?php

/* anime/delete.html.twig */
class __TwigTemplate_1e1733241bfad738d1a99805024f86d77b5ec52595ba01b7d3ebefb62963d267 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "anime/delete.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_196e87cfea3e98bdd34da771e39a21016b06af119c3c39000fdd6a1a598da144 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_196e87cfea3e98bdd34da771e39a21016b06af119c3c39000fdd6a1a598da144->enter($__internal_196e87cfea3e98bdd34da771e39a21016b06af119c3c39000fdd6a1a598da144_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "anime/delete.html.twig"));

        $__internal_eb7e5a60f8f2a9e9a52837a135c8270f019ca0dacddb7a3cf8a45fc76fecf5b0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eb7e5a60f8f2a9e9a52837a135c8270f019ca0dacddb7a3cf8a45fc76fecf5b0->enter($__internal_eb7e5a60f8f2a9e9a52837a135c8270f019ca0dacddb7a3cf8a45fc76fecf5b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "anime/delete.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_196e87cfea3e98bdd34da771e39a21016b06af119c3c39000fdd6a1a598da144->leave($__internal_196e87cfea3e98bdd34da771e39a21016b06af119c3c39000fdd6a1a598da144_prof);

        
        $__internal_eb7e5a60f8f2a9e9a52837a135c8270f019ca0dacddb7a3cf8a45fc76fecf5b0->leave($__internal_eb7e5a60f8f2a9e9a52837a135c8270f019ca0dacddb7a3cf8a45fc76fecf5b0_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_30b6459b1636fdc3ed63b6a34f41516ab5f29c4150895a747058089182b243b2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_30b6459b1636fdc3ed63b6a34f41516ab5f29c4150895a747058089182b243b2->enter($__internal_30b6459b1636fdc3ed63b6a34f41516ab5f29c4150895a747058089182b243b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_9abd9ef4ae7abb77c5391bb196db6f26ac746705a2d0d6b987c51cba29f5f6b7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9abd9ef4ae7abb77c5391bb196db6f26ac746705a2d0d6b987c51cba29f5f6b7->enter($__internal_9abd9ef4ae7abb77c5391bb196db6f26ac746705a2d0d6b987c51cba29f5f6b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "<h1>Delete Anime</h1>
<section>
    <form onsubmit=\"checkValue()\" method=\"POST\">
        <div>
            <label for=\"rating\">Rating</label>
            <input type=\"text\" id=\"rating\" value=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute(($context["anime"] ?? $this->getContext($context, "anime")), "rating", array()), "html", null, true);
        echo "\" name=\"anime[rating]\" disabled/>
            <label for=\"name\">Name</label>
            <input type=\"text\" id=\"name\" value=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute(($context["anime"] ?? $this->getContext($context, "anime")), "name", array()), "html", null, true);
        echo "\" name=\"anime[name]\" disabled/>
            <label for=\"description\">Description</label>
            <input type=\"text\" id=\"description\" value=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute(($context["anime"] ?? $this->getContext($context, "anime")), "description", array()), "html", null, true);
        echo "\" name=\"anime[description]\" disabled/>
            <label for=\"watched\">Watched</label>
            <input type=\"checkbox\" id=\"watched\" value=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute(($context["anime"] ?? $this->getContext($context, "anime")), "watched", array()), "html", null, true);
        echo "\" name=\"anime[watched]\" onclick=\"switchValue()\" disabled/>
            <label for=\"watched\" id=\"watched-label\"></label>

            ";
        // line 18
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'row');
        echo "

            <button type=\"submit\" class=\"accept\">Delete</button>
            <button type=\"button\" class=\"cancel\" onclick=\"location.href='/'\">Cancel</button>
        </div>
    </form>
</section>

<script>
    function checkValue() {
        document.getElementById(\"watched\").checked = true;
        document.getElementById(\"rating\").disabled = false;
        document.getElementById(\"name\").disabled = false;
        document.getElementById(\"description\").disabled = false;
        document.getElementById(\"status\").disabled = false;
    }

    (function checkBox() {
        let checkbox = document.getElementById(\"watched\");
        checkbox.checked = checkbox.value !== \"not watched\";
    })();
</script>
";
        
        $__internal_9abd9ef4ae7abb77c5391bb196db6f26ac746705a2d0d6b987c51cba29f5f6b7->leave($__internal_9abd9ef4ae7abb77c5391bb196db6f26ac746705a2d0d6b987c51cba29f5f6b7_prof);

        
        $__internal_30b6459b1636fdc3ed63b6a34f41516ab5f29c4150895a747058089182b243b2->leave($__internal_30b6459b1636fdc3ed63b6a34f41516ab5f29c4150895a747058089182b243b2_prof);

    }

    public function getTemplateName()
    {
        return "anime/delete.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  77 => 18,  71 => 15,  66 => 13,  61 => 11,  56 => 9,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
<h1>Delete Anime</h1>
<section>
    <form onsubmit=\"checkValue()\" method=\"POST\">
        <div>
            <label for=\"rating\">Rating</label>
            <input type=\"text\" id=\"rating\" value=\"{{ anime.rating }}\" name=\"anime[rating]\" disabled/>
            <label for=\"name\">Name</label>
            <input type=\"text\" id=\"name\" value=\"{{ anime.name }}\" name=\"anime[name]\" disabled/>
            <label for=\"description\">Description</label>
            <input type=\"text\" id=\"description\" value=\"{{ anime.description }}\" name=\"anime[description]\" disabled/>
            <label for=\"watched\">Watched</label>
            <input type=\"checkbox\" id=\"watched\" value=\"{{ anime.watched }}\" name=\"anime[watched]\" onclick=\"switchValue()\" disabled/>
            <label for=\"watched\" id=\"watched-label\"></label>

            {{ form_row(form._token) }}

            <button type=\"submit\" class=\"accept\">Delete</button>
            <button type=\"button\" class=\"cancel\" onclick=\"location.href='/'\">Cancel</button>
        </div>
    </form>
</section>

<script>
    function checkValue() {
        document.getElementById(\"watched\").checked = true;
        document.getElementById(\"rating\").disabled = false;
        document.getElementById(\"name\").disabled = false;
        document.getElementById(\"description\").disabled = false;
        document.getElementById(\"status\").disabled = false;
    }

    (function checkBox() {
        let checkbox = document.getElementById(\"watched\");
        checkbox.checked = checkbox.value !== \"not watched\";
    })();
</script>
{% endblock %}", "anime/delete.html.twig", "F:\\00. Work\\04. May-2017\\Software-Technologies-Retake-Exam-05-09-2017\\Skeletons\\PHP Solution\\app\\Resources\\views\\anime\\delete.html.twig");
    }
}
