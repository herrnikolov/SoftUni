<?php

/* anime/create.html.twig */
class __TwigTemplate_abd80478d8bc43ee04857dcd6cae94a8d053fbc1863bfb20f18d5073bc9039d4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "anime/create.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_408f8528112b1214279e312dba45910db93defbdcbb08a24d62c2c39045b58e6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_408f8528112b1214279e312dba45910db93defbdcbb08a24d62c2c39045b58e6->enter($__internal_408f8528112b1214279e312dba45910db93defbdcbb08a24d62c2c39045b58e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "anime/create.html.twig"));

        $__internal_693495edf3f90c45202abcfc675d61da38d03e5d4ca70bd7cbec26589f544f11 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_693495edf3f90c45202abcfc675d61da38d03e5d4ca70bd7cbec26589f544f11->enter($__internal_693495edf3f90c45202abcfc675d61da38d03e5d4ca70bd7cbec26589f544f11_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "anime/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_408f8528112b1214279e312dba45910db93defbdcbb08a24d62c2c39045b58e6->leave($__internal_408f8528112b1214279e312dba45910db93defbdcbb08a24d62c2c39045b58e6_prof);

        
        $__internal_693495edf3f90c45202abcfc675d61da38d03e5d4ca70bd7cbec26589f544f11->leave($__internal_693495edf3f90c45202abcfc675d61da38d03e5d4ca70bd7cbec26589f544f11_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_2d2efebbdbb45a2f735dfd1527abb0d0163a936cfa9bf0820f4c0eb059d62065 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2d2efebbdbb45a2f735dfd1527abb0d0163a936cfa9bf0820f4c0eb059d62065->enter($__internal_2d2efebbdbb45a2f735dfd1527abb0d0163a936cfa9bf0820f4c0eb059d62065_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_4acaf5ec6bf737e3e1bcb269d113212c41fc8fbef199aea150ff3b507bb83fce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4acaf5ec6bf737e3e1bcb269d113212c41fc8fbef199aea150ff3b507bb83fce->enter($__internal_4acaf5ec6bf737e3e1bcb269d113212c41fc8fbef199aea150ff3b507bb83fce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "<h1>Add New Anime</h1>
<section>
    <form method=\"POST\" onsubmit=\"checkValue()\">
        <div>
            <label for=\"rating\">Rating</label>
            <input type=\"text\" id=\"rating\" name=\"anime[rating]\" value=\"0\">
            <label for=\"name\">Name</label>
            <input type=\"text\" id=\"name\" name=\"anime[name]\">
            <label for=\"description\">Description</label>
            <input type=\"text\" id=\"description\" name=\"anime[description]\" value=\"...\">
            <label for=\"watched\">Watched</label>
            <input type=\"checkbox\" id=\"watched\" value=\"not watched\" name=\"anime[watched]\" onclick=\"switchValue()\">
            <label for=\"watched\" id=\"watched-label\"></label>
            ";
        // line 17
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'row');
        echo "

            <button type=\"submit\" class=\"accept\">Create</button>
            <button type=\"button\" class=\"cancel\" onclick=\"location.href='/'\">Cancel</button>
        </div>
    </form>
</section>

<script>
    function switchValue() {
        document.getElementById(\"watched\").value =
            document.getElementById(\"watched\").value === \"watched\" ? \"not watched\" : \"watched\";
    }

    function checkValue() {
        document.getElementById(\"watched\").checked = true;
    }

    (function checkBox() {
        let checkbox = document.getElementById(\"watched\");
        checkbox.checked = checkbox.value !== \"not watched\";
    })();
</script>
";
        
        $__internal_4acaf5ec6bf737e3e1bcb269d113212c41fc8fbef199aea150ff3b507bb83fce->leave($__internal_4acaf5ec6bf737e3e1bcb269d113212c41fc8fbef199aea150ff3b507bb83fce_prof);

        
        $__internal_2d2efebbdbb45a2f735dfd1527abb0d0163a936cfa9bf0820f4c0eb059d62065->leave($__internal_2d2efebbdbb45a2f735dfd1527abb0d0163a936cfa9bf0820f4c0eb059d62065_prof);

    }

    public function getTemplateName()
    {
        return "anime/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  64 => 17,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
<h1>Add New Anime</h1>
<section>
    <form method=\"POST\" onsubmit=\"checkValue()\">
        <div>
            <label for=\"rating\">Rating</label>
            <input type=\"text\" id=\"rating\" name=\"anime[rating]\" value=\"0\">
            <label for=\"name\">Name</label>
            <input type=\"text\" id=\"name\" name=\"anime[name]\">
            <label for=\"description\">Description</label>
            <input type=\"text\" id=\"description\" name=\"anime[description]\" value=\"...\">
            <label for=\"watched\">Watched</label>
            <input type=\"checkbox\" id=\"watched\" value=\"not watched\" name=\"anime[watched]\" onclick=\"switchValue()\">
            <label for=\"watched\" id=\"watched-label\"></label>
            {{ form_row(form._token) }}

            <button type=\"submit\" class=\"accept\">Create</button>
            <button type=\"button\" class=\"cancel\" onclick=\"location.href='/'\">Cancel</button>
        </div>
    </form>
</section>

<script>
    function switchValue() {
        document.getElementById(\"watched\").value =
            document.getElementById(\"watched\").value === \"watched\" ? \"not watched\" : \"watched\";
    }

    function checkValue() {
        document.getElementById(\"watched\").checked = true;
    }

    (function checkBox() {
        let checkbox = document.getElementById(\"watched\");
        checkbox.checked = checkbox.value !== \"not watched\";
    })();
</script>
{% endblock %}", "anime/create.html.twig", "F:\\00. Work\\04. May-2017\\Software-Technologies-Retake-Exam-05-09-2017\\Skeletons\\PHP Solution\\app\\Resources\\views\\anime\\create.html.twig");
    }
}
