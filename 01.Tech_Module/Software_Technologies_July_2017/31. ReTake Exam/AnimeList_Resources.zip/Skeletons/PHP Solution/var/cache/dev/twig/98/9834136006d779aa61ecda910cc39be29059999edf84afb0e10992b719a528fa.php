<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_09886c37796d81d574b2448cf2a22ea32da8dad546b69f22c376ce19a869ce97 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_689155b2b3be6c924b449935ba9eb1f84ab29f8cd585883aa17ab1d975c98b8e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_689155b2b3be6c924b449935ba9eb1f84ab29f8cd585883aa17ab1d975c98b8e->enter($__internal_689155b2b3be6c924b449935ba9eb1f84ab29f8cd585883aa17ab1d975c98b8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_c25cdb4b26dc0095326c1f7d5a7da0c7f2b8bf2e0c69c1ac07810d5a1fdeb8c3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c25cdb4b26dc0095326c1f7d5a7da0c7f2b8bf2e0c69c1ac07810d5a1fdeb8c3->enter($__internal_c25cdb4b26dc0095326c1f7d5a7da0c7f2b8bf2e0c69c1ac07810d5a1fdeb8c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_689155b2b3be6c924b449935ba9eb1f84ab29f8cd585883aa17ab1d975c98b8e->leave($__internal_689155b2b3be6c924b449935ba9eb1f84ab29f8cd585883aa17ab1d975c98b8e_prof);

        
        $__internal_c25cdb4b26dc0095326c1f7d5a7da0c7f2b8bf2e0c69c1ac07810d5a1fdeb8c3->leave($__internal_c25cdb4b26dc0095326c1f7d5a7da0c7f2b8bf2e0c69c1ac07810d5a1fdeb8c3_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_52bd022f1f372065afe55954ce9c8309b9bf63b0c1f4b94f3113148eb7b859d8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_52bd022f1f372065afe55954ce9c8309b9bf63b0c1f4b94f3113148eb7b859d8->enter($__internal_52bd022f1f372065afe55954ce9c8309b9bf63b0c1f4b94f3113148eb7b859d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_efcec5aef355bb027777a6541ef15cef551f7e7ee20fd20c17cad2adae15e8f6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_efcec5aef355bb027777a6541ef15cef551f7e7ee20fd20c17cad2adae15e8f6->enter($__internal_efcec5aef355bb027777a6541ef15cef551f7e7ee20fd20c17cad2adae15e8f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_efcec5aef355bb027777a6541ef15cef551f7e7ee20fd20c17cad2adae15e8f6->leave($__internal_efcec5aef355bb027777a6541ef15cef551f7e7ee20fd20c17cad2adae15e8f6_prof);

        
        $__internal_52bd022f1f372065afe55954ce9c8309b9bf63b0c1f4b94f3113148eb7b859d8->leave($__internal_52bd022f1f372065afe55954ce9c8309b9bf63b0c1f4b94f3113148eb7b859d8_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_f63c1a4aeceb694763f68ed714b2d883156682cea14e770f626f7b8fa6fbbd5b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f63c1a4aeceb694763f68ed714b2d883156682cea14e770f626f7b8fa6fbbd5b->enter($__internal_f63c1a4aeceb694763f68ed714b2d883156682cea14e770f626f7b8fa6fbbd5b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_59e084bee68ea673287d4dc0e8551f9f62bb5515098640d7622fb6bb904d3239 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_59e084bee68ea673287d4dc0e8551f9f62bb5515098640d7622fb6bb904d3239->enter($__internal_59e084bee68ea673287d4dc0e8551f9f62bb5515098640d7622fb6bb904d3239_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_59e084bee68ea673287d4dc0e8551f9f62bb5515098640d7622fb6bb904d3239->leave($__internal_59e084bee68ea673287d4dc0e8551f9f62bb5515098640d7622fb6bb904d3239_prof);

        
        $__internal_f63c1a4aeceb694763f68ed714b2d883156682cea14e770f626f7b8fa6fbbd5b->leave($__internal_f63c1a4aeceb694763f68ed714b2d883156682cea14e770f626f7b8fa6fbbd5b_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_4762dc3f07115f0066e3fcf15a1205154b14c101bffe3cd0c91518f1b1894c9e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4762dc3f07115f0066e3fcf15a1205154b14c101bffe3cd0c91518f1b1894c9e->enter($__internal_4762dc3f07115f0066e3fcf15a1205154b14c101bffe3cd0c91518f1b1894c9e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_eeb42c0c2cbb7eba5954614f8bebcb1a74895aaab5cdb85199673c1030646b1b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eeb42c0c2cbb7eba5954614f8bebcb1a74895aaab5cdb85199673c1030646b1b->enter($__internal_eeb42c0c2cbb7eba5954614f8bebcb1a74895aaab5cdb85199673c1030646b1b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_eeb42c0c2cbb7eba5954614f8bebcb1a74895aaab5cdb85199673c1030646b1b->leave($__internal_eeb42c0c2cbb7eba5954614f8bebcb1a74895aaab5cdb85199673c1030646b1b_prof);

        
        $__internal_4762dc3f07115f0066e3fcf15a1205154b14c101bffe3cd0c91518f1b1894c9e->leave($__internal_4762dc3f07115f0066e3fcf15a1205154b14c101bffe3cd0c91518f1b1894c9e_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "F:\\00. Work\\Software-Technologies-Exam-02-09-2017\\PHP Skeleton\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
