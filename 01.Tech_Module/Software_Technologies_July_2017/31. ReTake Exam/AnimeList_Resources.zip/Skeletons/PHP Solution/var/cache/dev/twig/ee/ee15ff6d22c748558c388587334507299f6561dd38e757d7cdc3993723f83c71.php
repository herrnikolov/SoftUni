<?php

/* product/edit.html.twig */
class __TwigTemplate_5c0698829a40ea1687906313f266f317c32a3cdbf0a5f60511808735ba5fb939 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "product/edit.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a42f4f578f7d7e707f5a888f1de34b3c01dc1ece75140473f9f749375306a1f9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a42f4f578f7d7e707f5a888f1de34b3c01dc1ece75140473f9f749375306a1f9->enter($__internal_a42f4f578f7d7e707f5a888f1de34b3c01dc1ece75140473f9f749375306a1f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "product/edit.html.twig"));

        $__internal_6337293149367bf5a3898889635317d0fad83c7e0a25c15efcab980780f84424 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6337293149367bf5a3898889635317d0fad83c7e0a25c15efcab980780f84424->enter($__internal_6337293149367bf5a3898889635317d0fad83c7e0a25c15efcab980780f84424_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "product/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a42f4f578f7d7e707f5a888f1de34b3c01dc1ece75140473f9f749375306a1f9->leave($__internal_a42f4f578f7d7e707f5a888f1de34b3c01dc1ece75140473f9f749375306a1f9_prof);

        
        $__internal_6337293149367bf5a3898889635317d0fad83c7e0a25c15efcab980780f84424->leave($__internal_6337293149367bf5a3898889635317d0fad83c7e0a25c15efcab980780f84424_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_2bc35317e09a4e3172f295fb757c473a0620a31f6e519af6bb7f5f90b6ea87de = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2bc35317e09a4e3172f295fb757c473a0620a31f6e519af6bb7f5f90b6ea87de->enter($__internal_2bc35317e09a4e3172f295fb757c473a0620a31f6e519af6bb7f5f90b6ea87de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_3def1c550fe9cba61cc9cd15bc650ca8c1acf6bb8832d3ddc99d01c97797c8ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3def1c550fe9cba61cc9cd15bc650ca8c1acf6bb8832d3ddc99d01c97797c8ad->enter($__internal_3def1c550fe9cba61cc9cd15bc650ca8c1acf6bb8832d3ddc99d01c97797c8ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "<h1>Edit Product</h1>
<section>
    <form onsubmit=\"checkValue()\" method=\"POST\">
        <div>
            <label for=\"priority\">Priority</label>
            <input type=\"text\" id=\"priority\" value=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? $this->getContext($context, "product")), "priority", array()), "html", null, true);
        echo "\" name=\"product[priority]\" />
            <label for=\"name\">Name</label>
            <input type=\"text\" id=\"name\" value=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? $this->getContext($context, "product")), "name", array()), "html", null, true);
        echo "\" name=\"product[name]\" />
            <label for=\"quantity\">Quantity</label>
            <input type=\"text\" id=\"quantity\" value=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? $this->getContext($context, "product")), "quantity", array()), "html", null, true);
        echo "\" name=\"product[quantity]\" />
            <label for=\"status\">Status</label>
            <input type=\"checkbox\" id=\"status\" value=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? $this->getContext($context, "product")), "status", array()), "html", null, true);
        echo "\" name=\"product[status]\" onclick=\"switchValue()\">
            <label for=\"status\" id=\"status-label\"></label>

            ";
        // line 18
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'row');
        echo "

            <button type=\"submit\" class=\"accept\">Edit</button>
            <button type=\"button\" class=\"cancel\" onclick=\"location.href='/'\">Cancel</button>
        </div>
    </form>
</section>

<script>
    function switchValue() {
        document.getElementById(\"status\").value =
                document.getElementById(\"status\").value === \"bought\" ? \"not bought\" : \"bought\";
    }

    function checkValue() {
        document.getElementById(\"status\").checked = true;
    }

    (function checkBox() {
        let checkbox = document.getElementById(\"status\");
        checkbox.checked = checkbox.value !== \"not bought\";
    })();
</script>
";
        
        $__internal_3def1c550fe9cba61cc9cd15bc650ca8c1acf6bb8832d3ddc99d01c97797c8ad->leave($__internal_3def1c550fe9cba61cc9cd15bc650ca8c1acf6bb8832d3ddc99d01c97797c8ad_prof);

        
        $__internal_2bc35317e09a4e3172f295fb757c473a0620a31f6e519af6bb7f5f90b6ea87de->leave($__internal_2bc35317e09a4e3172f295fb757c473a0620a31f6e519af6bb7f5f90b6ea87de_prof);

    }

    public function getTemplateName()
    {
        return "product/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  77 => 18,  71 => 15,  66 => 13,  61 => 11,  56 => 9,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
<h1>Edit Product</h1>
<section>
    <form onsubmit=\"checkValue()\" method=\"POST\">
        <div>
            <label for=\"priority\">Priority</label>
            <input type=\"text\" id=\"priority\" value=\"{{ product.priority }}\" name=\"product[priority]\" />
            <label for=\"name\">Name</label>
            <input type=\"text\" id=\"name\" value=\"{{ product.name }}\" name=\"product[name]\" />
            <label for=\"quantity\">Quantity</label>
            <input type=\"text\" id=\"quantity\" value=\"{{ product.quantity }}\" name=\"product[quantity]\" />
            <label for=\"status\">Status</label>
            <input type=\"checkbox\" id=\"status\" value=\"{{ product.status }}\" name=\"product[status]\" onclick=\"switchValue()\">
            <label for=\"status\" id=\"status-label\"></label>

            {{ form_row(form._token) }}

            <button type=\"submit\" class=\"accept\">Edit</button>
            <button type=\"button\" class=\"cancel\" onclick=\"location.href='/'\">Cancel</button>
        </div>
    </form>
</section>

<script>
    function switchValue() {
        document.getElementById(\"status\").value =
                document.getElementById(\"status\").value === \"bought\" ? \"not bought\" : \"bought\";
    }

    function checkValue() {
        document.getElementById(\"status\").checked = true;
    }

    (function checkBox() {
        let checkbox = document.getElementById(\"status\");
        checkbox.checked = checkbox.value !== \"not bought\";
    })();
</script>
{% endblock %}", "product/edit.html.twig", "F:\\00. Work\\Software-Technologies-Exam-02-09-2017\\PHP Skeleton\\app\\Resources\\views\\product\\edit.html.twig");
    }
}
