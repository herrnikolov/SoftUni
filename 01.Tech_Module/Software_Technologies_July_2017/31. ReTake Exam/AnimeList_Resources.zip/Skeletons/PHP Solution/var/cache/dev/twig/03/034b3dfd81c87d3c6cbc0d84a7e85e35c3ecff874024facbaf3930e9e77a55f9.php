<?php

/* @WebProfiler/Profiler/open.html.twig */
class __TwigTemplate_ac12c574132227140b686f2370e565f8f8810500cd69524bf391681d60e32a52 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "@WebProfiler/Profiler/open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9c09e998eacd858fa585179c3fb5b2a46f2a9a9350831d1aa436016321c896d3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9c09e998eacd858fa585179c3fb5b2a46f2a9a9350831d1aa436016321c896d3->enter($__internal_9c09e998eacd858fa585179c3fb5b2a46f2a9a9350831d1aa436016321c896d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $__internal_2cfeccc77267cb73d3e68a0f53922e1f5f0f87aae2de16c63985cb2d01a82eaf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2cfeccc77267cb73d3e68a0f53922e1f5f0f87aae2de16c63985cb2d01a82eaf->enter($__internal_2cfeccc77267cb73d3e68a0f53922e1f5f0f87aae2de16c63985cb2d01a82eaf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9c09e998eacd858fa585179c3fb5b2a46f2a9a9350831d1aa436016321c896d3->leave($__internal_9c09e998eacd858fa585179c3fb5b2a46f2a9a9350831d1aa436016321c896d3_prof);

        
        $__internal_2cfeccc77267cb73d3e68a0f53922e1f5f0f87aae2de16c63985cb2d01a82eaf->leave($__internal_2cfeccc77267cb73d3e68a0f53922e1f5f0f87aae2de16c63985cb2d01a82eaf_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_dabfa267b556d6bcffeb3b5d6ef12f8c78c246b9cf581575816a70b695faf7e2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dabfa267b556d6bcffeb3b5d6ef12f8c78c246b9cf581575816a70b695faf7e2->enter($__internal_dabfa267b556d6bcffeb3b5d6ef12f8c78c246b9cf581575816a70b695faf7e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_04071577b996c96fdd48a494ba896c3368ebbd49fc2045a29eb013e240c5006d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_04071577b996c96fdd48a494ba896c3368ebbd49fc2045a29eb013e240c5006d->enter($__internal_04071577b996c96fdd48a494ba896c3368ebbd49fc2045a29eb013e240c5006d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_04071577b996c96fdd48a494ba896c3368ebbd49fc2045a29eb013e240c5006d->leave($__internal_04071577b996c96fdd48a494ba896c3368ebbd49fc2045a29eb013e240c5006d_prof);

        
        $__internal_dabfa267b556d6bcffeb3b5d6ef12f8c78c246b9cf581575816a70b695faf7e2->leave($__internal_dabfa267b556d6bcffeb3b5d6ef12f8c78c246b9cf581575816a70b695faf7e2_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_32efbecf6abf90ef651207046876e0572f0f950bce3c71270fe2f84cf674c362 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_32efbecf6abf90ef651207046876e0572f0f950bce3c71270fe2f84cf674c362->enter($__internal_32efbecf6abf90ef651207046876e0572f0f950bce3c71270fe2f84cf674c362_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f735a8cfd74a6adefb1aa6986b8927f552027e32908d0496ea51c0a3dd3a0abd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f735a8cfd74a6adefb1aa6986b8927f552027e32908d0496ea51c0a3dd3a0abd->enter($__internal_f735a8cfd74a6adefb1aa6986b8927f552027e32908d0496ea51c0a3dd3a0abd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, ($context["file"] ?? $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, ($context["line"] ?? $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt(($context["filename"] ?? $this->getContext($context, "filename")), ($context["line"] ?? $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_f735a8cfd74a6adefb1aa6986b8927f552027e32908d0496ea51c0a3dd3a0abd->leave($__internal_f735a8cfd74a6adefb1aa6986b8927f552027e32908d0496ea51c0a3dd3a0abd_prof);

        
        $__internal_32efbecf6abf90ef651207046876e0572f0f950bce3c71270fe2f84cf674c362->leave($__internal_32efbecf6abf90ef651207046876e0572f0f950bce3c71270fe2f84cf674c362_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "@WebProfiler/Profiler/open.html.twig", "F:\\00. Work\\04. May-2017\\Software-Technologies-Retake-Exam-05-09-2017\\Skeletons\\PHP Solution\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\open.html.twig");
    }
}
