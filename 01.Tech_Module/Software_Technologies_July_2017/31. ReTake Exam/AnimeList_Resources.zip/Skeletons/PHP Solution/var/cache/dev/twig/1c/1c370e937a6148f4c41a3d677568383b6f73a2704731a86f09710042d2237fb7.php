<?php

/* product/create.html.twig */
class __TwigTemplate_0d5b022a18fdac8493305d3052c6f1db01c904a6c1d46a6c0deac63e8abff755 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "product/create.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bde8cd59386bdbfd9990d06a9d9c3ee074aa9f8888af40fd55d81d95c1941b63 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bde8cd59386bdbfd9990d06a9d9c3ee074aa9f8888af40fd55d81d95c1941b63->enter($__internal_bde8cd59386bdbfd9990d06a9d9c3ee074aa9f8888af40fd55d81d95c1941b63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "product/create.html.twig"));

        $__internal_08f3ad575241dee1ed447b2756911bd4034d4b05bf852c0c2c4205d9232fc04e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_08f3ad575241dee1ed447b2756911bd4034d4b05bf852c0c2c4205d9232fc04e->enter($__internal_08f3ad575241dee1ed447b2756911bd4034d4b05bf852c0c2c4205d9232fc04e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "product/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bde8cd59386bdbfd9990d06a9d9c3ee074aa9f8888af40fd55d81d95c1941b63->leave($__internal_bde8cd59386bdbfd9990d06a9d9c3ee074aa9f8888af40fd55d81d95c1941b63_prof);

        
        $__internal_08f3ad575241dee1ed447b2756911bd4034d4b05bf852c0c2c4205d9232fc04e->leave($__internal_08f3ad575241dee1ed447b2756911bd4034d4b05bf852c0c2c4205d9232fc04e_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_0d20d822b5ae32f91dc191c4517b158c6f1447a0204a58e53ad49be3e1c14640 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0d20d822b5ae32f91dc191c4517b158c6f1447a0204a58e53ad49be3e1c14640->enter($__internal_0d20d822b5ae32f91dc191c4517b158c6f1447a0204a58e53ad49be3e1c14640_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_65e7d21474521bfd2da66cb7b9ce300e73b285bae083ec36b38fbe221e50df6d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_65e7d21474521bfd2da66cb7b9ce300e73b285bae083ec36b38fbe221e50df6d->enter($__internal_65e7d21474521bfd2da66cb7b9ce300e73b285bae083ec36b38fbe221e50df6d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "<h1>Add New Product</h1>
<section>
    <form method=\"POST\">
        <div>
            <label for=\"priority\">Priority</label>
            <input type=\"text\" id=\"priority\" name=\"product[priority]\" value=\"1\">
            <label for=\"name\">Name</label>
            <input type=\"text\" id=\"name\" name=\"product[name]\">
            <label for=\"quantity\">Quantity</label>
            <input type=\"text\" id=\"quantity\" name=\"product[quantity]\" value=\"1\">
\t\t\t<input type=\"hidden\" name=\"product[status]\" value=\"not bought\">
            ";
        // line 15
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'row');
        echo "

            <button type=\"submit\" class=\"accept\">Create</button>
            <button type=\"button\" class=\"cancel\" onclick=\"location.href='/'\">Cancel</button>
        </div>
    </form>
</section>
";
        
        $__internal_65e7d21474521bfd2da66cb7b9ce300e73b285bae083ec36b38fbe221e50df6d->leave($__internal_65e7d21474521bfd2da66cb7b9ce300e73b285bae083ec36b38fbe221e50df6d_prof);

        
        $__internal_0d20d822b5ae32f91dc191c4517b158c6f1447a0204a58e53ad49be3e1c14640->leave($__internal_0d20d822b5ae32f91dc191c4517b158c6f1447a0204a58e53ad49be3e1c14640_prof);

    }

    public function getTemplateName()
    {
        return "product/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  62 => 15,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
<h1>Add New Product</h1>
<section>
    <form method=\"POST\">
        <div>
            <label for=\"priority\">Priority</label>
            <input type=\"text\" id=\"priority\" name=\"product[priority]\" value=\"1\">
            <label for=\"name\">Name</label>
            <input type=\"text\" id=\"name\" name=\"product[name]\">
            <label for=\"quantity\">Quantity</label>
            <input type=\"text\" id=\"quantity\" name=\"product[quantity]\" value=\"1\">
\t\t\t<input type=\"hidden\" name=\"product[status]\" value=\"not bought\">
            {{ form_row(form._token) }}

            <button type=\"submit\" class=\"accept\">Create</button>
            <button type=\"button\" class=\"cancel\" onclick=\"location.href='/'\">Cancel</button>
        </div>
    </form>
</section>
{% endblock %}", "product/create.html.twig", "F:\\00. Work\\Software-Technologies-Exam-02-09-2017\\PHP Solution\\app\\Resources\\views\\product\\create.html.twig");
    }
}
