<?php

/* base.html.twig */
class __TwigTemplate_93e2499d03c6402ea1e3906495568257ed0120721f7f5badb0e11600e82927c5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_47bbcf53ca1f0cea2995c471cdf2fe1f7d41f6db03b21fb9a47ee9a8b1105dc7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_47bbcf53ca1f0cea2995c471cdf2fe1f7d41f6db03b21fb9a47ee9a8b1105dc7->enter($__internal_47bbcf53ca1f0cea2995c471cdf2fe1f7d41f6db03b21fb9a47ee9a8b1105dc7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_7c995320144b72b42244b49eb368cc1526430f7b75a6a08f7ed5178d3fb9c481 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7c995320144b72b42244b49eb368cc1526430f7b75a6a08f7ed5178d3fb9c481->enter($__internal_7c995320144b72b42244b49eb368cc1526430f7b75a6a08f7ed5178d3fb9c481_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 17
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 20
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">
";
        // line 21
        $this->displayBlock('body', $context, $blocks);
        // line 24
        echo "</body>
</html>
";
        
        $__internal_47bbcf53ca1f0cea2995c471cdf2fe1f7d41f6db03b21fb9a47ee9a8b1105dc7->leave($__internal_47bbcf53ca1f0cea2995c471cdf2fe1f7d41f6db03b21fb9a47ee9a8b1105dc7_prof);

        
        $__internal_7c995320144b72b42244b49eb368cc1526430f7b75a6a08f7ed5178d3fb9c481->leave($__internal_7c995320144b72b42244b49eb368cc1526430f7b75a6a08f7ed5178d3fb9c481_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_e696071af23ab455d4841108dca153d1e29f3362af2e05a646523a5378242831 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e696071af23ab455d4841108dca153d1e29f3362af2e05a646523a5378242831->enter($__internal_e696071af23ab455d4841108dca153d1e29f3362af2e05a646523a5378242831_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_995c27e2d1e93a4e22679bde2e91776393e14fc3c13ec93f8b36456018f042c3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_995c27e2d1e93a4e22679bde2e91776393e14fc3c13ec93f8b36456018f042c3->enter($__internal_995c27e2d1e93a4e22679bde2e91776393e14fc3c13ec93f8b36456018f042c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Anime List";
        
        $__internal_995c27e2d1e93a4e22679bde2e91776393e14fc3c13ec93f8b36456018f042c3->leave($__internal_995c27e2d1e93a4e22679bde2e91776393e14fc3c13ec93f8b36456018f042c3_prof);

        
        $__internal_e696071af23ab455d4841108dca153d1e29f3362af2e05a646523a5378242831->leave($__internal_e696071af23ab455d4841108dca153d1e29f3362af2e05a646523a5378242831_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_0ddae549cb8f8cc0c422fb9a868bcb8efaa78475dfb862e2c711710cad0971d6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0ddae549cb8f8cc0c422fb9a868bcb8efaa78475dfb862e2c711710cad0971d6->enter($__internal_0ddae549cb8f8cc0c422fb9a868bcb8efaa78475dfb862e2c711710cad0971d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_05a64ff76d36b303123ca4d73b0b1a3cf7303fe82e9bd223de2c5ef92611c7b9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_05a64ff76d36b303123ca4d73b0b1a3cf7303fe82e9bd223de2c5ef92611c7b9->enter($__internal_05a64ff76d36b303123ca4d73b0b1a3cf7303fe82e9bd223de2c5ef92611c7b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        ";
        // line 14
        echo "        ";
        // line 15
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_05a64ff76d36b303123ca4d73b0b1a3cf7303fe82e9bd223de2c5ef92611c7b9->leave($__internal_05a64ff76d36b303123ca4d73b0b1a3cf7303fe82e9bd223de2c5ef92611c7b9_prof);

        
        $__internal_0ddae549cb8f8cc0c422fb9a868bcb8efaa78475dfb862e2c711710cad0971d6->leave($__internal_0ddae549cb8f8cc0c422fb9a868bcb8efaa78475dfb862e2c711710cad0971d6_prof);

    }

    // line 20
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_0847aea5c3e870b7049d86da8f1544f686bc106b64364cd23fcdd2eadcb25fcf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0847aea5c3e870b7049d86da8f1544f686bc106b64364cd23fcdd2eadcb25fcf->enter($__internal_0847aea5c3e870b7049d86da8f1544f686bc106b64364cd23fcdd2eadcb25fcf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_0a9cce4125d56f414ddafc186dfe68c8bc5f831dc5cdd7962982f8963f1fbde7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0a9cce4125d56f414ddafc186dfe68c8bc5f831dc5cdd7962982f8963f1fbde7->enter($__internal_0a9cce4125d56f414ddafc186dfe68c8bc5f831dc5cdd7962982f8963f1fbde7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_0a9cce4125d56f414ddafc186dfe68c8bc5f831dc5cdd7962982f8963f1fbde7->leave($__internal_0a9cce4125d56f414ddafc186dfe68c8bc5f831dc5cdd7962982f8963f1fbde7_prof);

        
        $__internal_0847aea5c3e870b7049d86da8f1544f686bc106b64364cd23fcdd2eadcb25fcf->leave($__internal_0847aea5c3e870b7049d86da8f1544f686bc106b64364cd23fcdd2eadcb25fcf_prof);

    }

    // line 21
    public function block_body($context, array $blocks = array())
    {
        $__internal_5b2ecfaed49bf1e2e58453d6be1d22f3e54f94f53f2f5f7dbd89b9adc7a1b3db = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5b2ecfaed49bf1e2e58453d6be1d22f3e54f94f53f2f5f7dbd89b9adc7a1b3db->enter($__internal_5b2ecfaed49bf1e2e58453d6be1d22f3e54f94f53f2f5f7dbd89b9adc7a1b3db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_3a3b9563b9b75be931943bd4b484a00dbf9e92120f616e6a210a498e7641e394 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3a3b9563b9b75be931943bd4b484a00dbf9e92120f616e6a210a498e7641e394->enter($__internal_3a3b9563b9b75be931943bd4b484a00dbf9e92120f616e6a210a498e7641e394_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 22
        echo "    ";
        $this->displayBlock('main', $context, $blocks);
        
        $__internal_3a3b9563b9b75be931943bd4b484a00dbf9e92120f616e6a210a498e7641e394->leave($__internal_3a3b9563b9b75be931943bd4b484a00dbf9e92120f616e6a210a498e7641e394_prof);

        
        $__internal_5b2ecfaed49bf1e2e58453d6be1d22f3e54f94f53f2f5f7dbd89b9adc7a1b3db->leave($__internal_5b2ecfaed49bf1e2e58453d6be1d22f3e54f94f53f2f5f7dbd89b9adc7a1b3db_prof);

    }

    public function block_main($context, array $blocks = array())
    {
        $__internal_92a25847d3d63b5af988661c2eced47761aa04bc9b6ce292af604d9aff6d70d3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_92a25847d3d63b5af988661c2eced47761aa04bc9b6ce292af604d9aff6d70d3->enter($__internal_92a25847d3d63b5af988661c2eced47761aa04bc9b6ce292af604d9aff6d70d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_6e47a66f02694c7be0e5f5ed97bdd1afccaebe53749c0a421772e379ee1694ca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6e47a66f02694c7be0e5f5ed97bdd1afccaebe53749c0a421772e379ee1694ca->enter($__internal_6e47a66f02694c7be0e5f5ed97bdd1afccaebe53749c0a421772e379ee1694ca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_6e47a66f02694c7be0e5f5ed97bdd1afccaebe53749c0a421772e379ee1694ca->leave($__internal_6e47a66f02694c7be0e5f5ed97bdd1afccaebe53749c0a421772e379ee1694ca_prof);

        
        $__internal_92a25847d3d63b5af988661c2eced47761aa04bc9b6ce292af604d9aff6d70d3->leave($__internal_92a25847d3d63b5af988661c2eced47761aa04bc9b6ce292af604d9aff6d70d3_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 22,  129 => 21,  112 => 20,  99 => 15,  97 => 14,  95 => 13,  86 => 12,  68 => 11,  56 => 24,  54 => 21,  50 => 20,  43 => 17,  41 => 12,  37 => 11,  30 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}Anime List{% endblock %}</title>
    {% block stylesheets %}
        {#<link rel=\"stylesheet\" href=\"{{ asset('css/reset-style.css') }}\">;#}
        {#<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\">#}
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">
{% block body %}
    {% block main %}{% endblock %}
{% endblock %}
</body>
</html>
", "base.html.twig", "F:\\00. Work\\04. May-2017\\Software-Technologies-Retake-Exam-05-09-2017\\Skeletons\\PHP Solution\\app\\Resources\\views\\base.html.twig");
    }
}
